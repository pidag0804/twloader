#include "CowMod.h"

bool CowMod::Init(ModLoader* cMod)
{
	
	return 0;
}

void CowMod::OnStartGame()
{
	return;
}

CowMod::CModInfo* CowMod::getInfo()
{
	return 0;
}


CowMod::impObject* CowMod::getImpList()
{
	return 0;
}

