/* Replace "dll.h" with the name of your header */
#include <windows.h>
#include "ResizeWindowsMod.h"
ResizeWindowsMod* thisMod = 0;

extern "C" void* _stdcall DllMain(HINSTANCE hinstDLL,DWORD fdwReason,LPVOID lpvReserved)
{
	switch(fdwReason)
	{
		case DLL_PROCESS_ATTACH:
		{
			thisMod = new ResizeWindowsMod();
			return thisMod;
		}
		case DLL_PROCESS_DETACH:
		{
			if(thisMod != 0)
				delete thisMod;
			break;
		}
		case DLL_THREAD_ATTACH:
		{
			break;
		}
		case DLL_THREAD_DETACH:
		{
			break;
		}
	}


	return 0;
}
